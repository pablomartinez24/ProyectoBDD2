﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Drawing.Printing;
using System.Net;

namespace proyecto2
{
    public class Back
    {
        SqlConnection CONECTION = new SqlConnection();
        string DATACONECTION = "Server=LAPTOP-FIRLFN8E;Database=EXAMENYTAREA;Trusted_Connection=True;";

        //metodo de hacer conexion a la bdd
        public SqlConnection CREATECONECTION()
        {
            try
            {
                CONECTION.ConnectionString = DATACONECTION;
                CONECTION.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show("No se conecto correctamente a la base de datos, error:" + e.ToString());
            }
            return CONECTION;
        }

        //metodo de cerrar conexion a la bdd
        public void CLOSECONECTION()
        {
            CONECTION.Close();
        }

        //metodo para insertar datos en la tabla products
        public void LOADDATAProducts(System.Windows.Forms.TextBox Descripcion, NumericUpDown id_Marca, NumericUpDown id_Categoria, NumericUpDown precio)
        {
            try
            {
                String query = "INSERT INTO products (Descripcion, id_Marca, id_Categoria, precio, Imagen) values('" + Descripcion.Text.ToString() + "'," + id_Marca.Value + "," + id_Categoria.Value + "," + precio.Value + "," + "'Imagen');";
                SqlCommand cmd = new SqlCommand(query, CREATECONECTION());
                SqlDataReader dr = cmd.ExecuteReader();             
                CLOSECONECTION();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo insertar el registro: " + ex);
            }
        }

        //metodo para cargar el inventario a un datagrid
        public void GETInventario(DataGridView DATAGRIDiNVENTORY)
        {
            try
            {
                DATAGRIDiNVENTORY.DataSource = null;
                SqlDataAdapter adapter = new SqlDataAdapter("CargarInventario", CREATECONECTION());
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                DATAGRIDiNVENTORY.DataSource = dt;
                CLOSECONECTION();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se logro cargar los registros al inventario : " + ex);
            }
        }

        //metodo para cargar los productos a un datagrid
        public void GETProductos(DataGridView dataGridViewProductos)
        {
            try
            {
                dataGridViewProductos.DataSource = null;
                SqlDataAdapter adapter = new SqlDataAdapter("CargarProducto", CREATECONECTION());
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridViewProductos.DataSource = dt;
                CLOSECONECTION();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se logro cargar los registros al productos : " + ex);
            }
        }

        //metodo para cargar los cliente a un combobox
        public void LOADCLIENTESCOMPRA(System.Windows.Forms.ComboBox comboBoxCLiente)
        {
            string query = "SELECT Nombre FROM customer";
            SqlConnection connection = CREATECONECTION();
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string nombreCliente = reader["Nombre"].ToString();
                comboBoxCLiente.Items.Add(nombreCliente);
            }
            reader.Close();
            connection.Close();
        }

        //metodo para cargar el precio del producto a la vez que se selecciona en el combo box
        public decimal GetIdCliente(string nombreCliente)
        {
            decimal IdCliente = 0;
            string query = "SELECT CodigoCliente FROM customer WHERE Nombre = @nombre";
            using (SqlConnection connection = CREATECONECTION())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nombre", nombreCliente);
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        IdCliente = Convert.ToDecimal(result);
                    }
                }
            }
            return IdCliente;
        }


        //metodo para cargar los productos a un combobox y a la vez su codigo y precio
        public void LOADPRODUCTOSCOMPRA(System.Windows.Forms.ComboBox ComboBoxnameproducts)
        {
            string query = "SELECT Descripcion FROM products";
            SqlConnection connection = CREATECONECTION();
            SqlCommand cmd = new SqlCommand(query, connection);       
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string nombreProducto = reader["Descripcion"].ToString();
                ComboBoxnameproducts.Items.Add(nombreProducto);
            }
            reader.Close();
            connection.Close();

        }
        public decimal GetPrecioProducto(string nombreProducto)
        {
            decimal precio = 0;
            string query = "SELECT Precio FROM products WHERE Descripcion = @nombre";
            using (SqlConnection connection = CREATECONECTION())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nombre", nombreProducto);
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        precio = Convert.ToDecimal(result);
                    }
                }
            }
            return precio;
        }
        public decimal GetIdProducto(string idProducto)
        {
            decimal id = 0;
            string query = "SELECT idProducto FROM products WHERE Descripcion = @nombre";
            using (SqlConnection connection = CREATECONECTION())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nombre", idProducto);
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        id = Convert.ToDecimal(result);
                    }
                }
            }
            return id;
        }


        

        //metodo para cargar el nombre del cliente a nuestro combobox
        public void LOADCLIENTESVENTAS(System.Windows.Forms.ComboBox comboBoxCLiente)
        {
            string query = "SELECT Nombre FROM customer";
            SqlConnection connection = CREATECONECTION();
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string nombreCliente = reader["Nombre"].ToString();
                comboBoxCLiente.Items.Add(nombreCliente);
            }
            reader.Close();
            connection.Close();
        }

        //carga la tabla customer(clientes)
        public void LOADDATAClientes(System.Windows.Forms.TextBox NombreCliente, System.Windows.Forms.TextBox DireccionCliente, System.Windows.Forms.TextBox CorreoCliente, System.Windows.Forms.TextBox NitCliente)
        {
            try
            {
                String query = "INSERT INTO customer (Nombre, Direccion, Correo, Nit) VALUES ('" + NombreCliente.Text.ToString() + "','" + DireccionCliente.Text.ToString() + "','" + CorreoCliente.Text.ToString() + "','" + NitCliente.Text.ToString() + "',);";
                SqlCommand cmd = new SqlCommand(query, CREATECONECTION());
                SqlDataReader dr = cmd.ExecuteReader();         
                CLOSECONECTION();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo insertar el registro" + ex);
            }
        }


        //carga la tabla sales_h
        public void LOADDATASalesH( NumericUpDown textBoxSeriesSalesH, System.Windows.Forms.TextBox textBoxIdCliente)
        {
            int numero;
            string text = textBoxIdCliente.Text;
            int.TryParse(text, out numero);
            try
            {
                String query = "INSERT INTO sales_h (Serie, Fecha, Codigo_Cliente, Nit) VALUES(" + textBoxSeriesSalesH.Value + ",'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")  + "',"+ numero + ", 1);";
                SqlCommand cmd = new SqlCommand(query, CREATECONECTION());
                SqlDataReader dr = cmd.ExecuteReader();
                CLOSECONECTION();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo insertar el registro" + ex);
            }
        }



        //metodo para cargar los productos a un combobox
        public int LOANUMEROFACTURA()
        {
            string query = "SELECT MAX(Numero) FROM sales_h";
            SqlConnection connection = CREATECONECTION();
            SqlCommand command = new SqlCommand(query, connection);
            object reader = command.ExecuteScalar();
              int lastNumero = 0;
            if (reader != null && reader != DBNull.Value)
            {
             lastNumero = Convert.ToInt32(reader);
            }           
            connection.Close();
            return lastNumero;
        }

        //metodo para cargar la tabla sales_d
       public void LOADDATASalesD(NumericUpDown CantidadCompra, System.Windows.Forms.TextBox TextBoxIdProducto, System.Windows.Forms.TextBox NumeroSalesH, System.Windows.Forms.NumericUpDown textBoxSeriesSalesH)
        {
            int INTidProducto;
            string textIdProducto = TextBoxIdProducto.Text;
            int.TryParse(textIdProducto, out INTidProducto);

            int INTNumeroFactura;
            string textNumeroFactura = NumeroSalesH.Text;
            int.TryParse(textNumeroFactura, out INTNumeroFactura);
            try
            {
                String query = "INSERT INTO sales_d (Cantidad, Articulo, Factura, Serie) VALUES(" + CantidadCompra.Value + "," + INTidProducto + "," + INTNumeroFactura + ", " + textBoxSeriesSalesH.Value + ");";
                SqlCommand cmd = new SqlCommand(query, CREATECONECTION());
                SqlDataReader dr = cmd.ExecuteReader();
                CLOSECONECTION();

                string querydos = "UPDATE inventory SET stock_in = stock_in-" + CantidadCompra.Value + ", outlets = outlets+"+ CantidadCompra.Value + " WHERE id_product = " + INTidProducto + ";";
                SqlCommand cmdd = new SqlCommand(querydos, CREATECONECTION());
                SqlDataReader drd = cmdd.ExecuteReader();
                CLOSECONECTION();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo insertar el registro" + ex);
            }
        }

        public void AUMENTARSTOCK(System.Windows.Forms.TextBox TextBoxIdProductoADMIN, System.Windows.Forms.NumericUpDown CantidadaggADMIN)
        {
            int IdProducto = Convert.ToInt32(TextBoxIdProductoADMIN.Text);
            try
            {
                string selectQuery = "UPDATE inventory SET stock_in = stock_in+" + CantidadaggADMIN.Value + ", entries = entries +"+ CantidadaggADMIN.Value+" WHERE id_product = " + IdProducto + ";";
                SqlCommand cmd = new SqlCommand(selectQuery, CREATECONECTION());
                SqlDataReader dr = cmd.ExecuteReader();
                CLOSECONECTION();          
            }
            catch
            {
                MessageBox.Show("No Se actualizo el stock ");
            }
        }


        public int VERIFYSTOCK(System.Windows.Forms.TextBox TextBoxIdProducto)
        {
            int IProducto = 0;
            int idprod = Convert.ToInt32(TextBoxIdProducto.Text);
            try
            {           
                string QueryVer = "SELECT stock_in FROM inventory WHERE id_product=" + idprod + ";";
                SqlCommand cmd = new SqlCommand(QueryVer, CREATECONECTION());                                                 
                IProducto = Convert.ToInt32(cmd.ExecuteScalar());
                CLOSECONECTION();
            }
            catch
            {
                MessageBox.Show("no se puede analizar el stock");               
            }
            return IProducto;          
        }
    }
}

