﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;


namespace proyecto2
{
    public partial class Ventas : Form
    {
        Back objetConexion;
        public Ventas()
        {
            InitializeComponent();
            objetConexion = new Back();

        }

        PrintDocument printDocument1;

        void Ventas_Load(object sender, EventArgs e)
        {
            objetConexion.GETProductos(dataGridViewProductosMuestra);
            objetConexion.LOADPRODUCTOSCOMPRA(comboBoxnameproducts);
            objetConexion.LOADCLIENTESCOMPRA(comboBoxCLiente);
        }

        void BTNAGGPRODUCT_Click(object sender, EventArgs e)
        {          
            int cantidadstock = objetConexion.VERIFYSTOCK(TextBoxIdProducto);
            int cantidacomp = Convert.ToInt32(CantidadCompra.Value);
            if(cantidadstock < cantidacomp)
            {
                MessageBox.Show("no se puede vender una cantidad mayor al stock");
            }
            else
            {
                objetConexion.LOADDATASalesH(textBoxSeriesSalesH, textBoxIdCliente);
                decimal numeroSalesH = objetConexion.LOANUMEROFACTURA();
                NumeroSalesH.Text = numeroSalesH.ToString();
                objetConexion.LOADDATASalesD(CantidadCompra, TextBoxIdProducto, NumeroSalesH, textBoxSeriesSalesH);
                printDocument1 = new PrintDocument();
                PrinterSettings settings = new PrinterSettings();
                printDocument1.PrinterSettings = settings;
                printDocument1.PrintPage += CREARFACTURA;
                printDocument1.Print();
                this.Close();
            }
        }



        void comboBoxnameproducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedProduct = comboBoxnameproducts.SelectedItem.ToString();
            decimal precio = objetConexion.GetPrecioProducto(selectedProduct);
            decimal CodigoProducto = objetConexion.GetIdProducto(selectedProduct);
            textBoxdelPrecio.Text = precio.ToString();
            TextBoxIdProducto.Text = CodigoProducto.ToString();
        }

        private void comboBoxCLiente_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedClient = comboBoxCLiente.SelectedItem.ToString();
            decimal id = objetConexion.GetIdCliente(selectedClient);
            textBoxIdCliente.Text =  id.ToString();
        }


        public void CREARFACTURA(object sender, PrintPageEventArgs e)
        {

            Font font = new Font("Bodoni MT", 8);
            int ancho = 500;
            int y = 20;

            int Cantidad;
            string cantidacad = CantidadCompra.Text;
            int.TryParse(cantidacad, out Cantidad);

            int Total;
            string text2 = textBoxdelPrecio.Text;
            int.TryParse(text2, out Total);
            Total = Total * Cantidad;

            e.Graphics.DrawString(" __________________________FACTURA___________________________ ", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|Factura No.:  " + NumeroSalesH.Text + "                          |", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|____________________________________________________________|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|Cliente:  " + comboBoxCLiente.Text + "                           |", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|____________________________________________________________|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|Fecha:  " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|____________________________________________________________|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|id | Descripcion      | precio   | cantidad   | total       |", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|___|__________________|__________|____________|_____________|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|"+ TextBoxIdProducto.Text+"   |"+ comboBoxnameproducts.Text + "     |"+textBoxdelPrecio.Text + "    |"+cantidacad.ToString() + "    |"+Total.ToString() + " |", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
        }
    }
}
