﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto2
{
    public partial class AdminStok : Form
    {
        Back objetConexion;
        public AdminStok()
        {
            InitializeComponent();
            objetConexion = new Back();

        }

        private void AdminStok_Load(object sender, EventArgs e)
        {
            objetConexion.LOADPRODUCTOSCOMPRA(comboBoxnameproductsADMIN);
        }

        private void AGREGAR_Click(object sender, EventArgs e)
        {
            objetConexion.AUMENTARSTOCK(TextBoxIdProductoADMIN,CantidadaggADMIN);
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();

        }

        private void comboBoxnameproductsADMIN_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedProduct = comboBoxnameproductsADMIN.SelectedItem.ToString();
            decimal precio = objetConexion.GetPrecioProducto(selectedProduct);
            decimal CodigoProducto = objetConexion.GetIdProducto(selectedProduct);
            textBoxdelPrecioADMIN.Text = precio.ToString();
            TextBoxIdProductoADMIN.Text = CodigoProducto.ToString();
        }

        private void CantidadaggADMIN_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
