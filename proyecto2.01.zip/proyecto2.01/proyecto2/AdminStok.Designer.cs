﻿
namespace proyecto2
{
    partial class AdminStok
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.TextBoxIdProductoADMIN = new System.Windows.Forms.TextBox();
            this.textBoxdelPrecioADMIN = new System.Windows.Forms.TextBox();
            this.AGREGAR = new System.Windows.Forms.Button();
            this.CantidadaggADMIN = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxnameproductsADMIN = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CantidadaggADMIN)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.TextBoxIdProductoADMIN);
            this.panel1.Controls.Add(this.textBoxdelPrecioADMIN);
            this.panel1.Controls.Add(this.AGREGAR);
            this.panel1.Controls.Add(this.CantidadaggADMIN);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.comboBoxnameproductsADMIN);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(217, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(366, 450);
            this.panel1.TabIndex = 7;
            // 
            // TextBoxIdProductoADMIN
            // 
            this.TextBoxIdProductoADMIN.Location = new System.Drawing.Point(122, 94);
            this.TextBoxIdProductoADMIN.Name = "TextBoxIdProductoADMIN";
            this.TextBoxIdProductoADMIN.Size = new System.Drawing.Size(105, 20);
            this.TextBoxIdProductoADMIN.TabIndex = 15;
            // 
            // textBoxdelPrecioADMIN
            // 
            this.textBoxdelPrecioADMIN.Location = new System.Drawing.Point(233, 116);
            this.textBoxdelPrecioADMIN.Name = "textBoxdelPrecioADMIN";
            this.textBoxdelPrecioADMIN.Size = new System.Drawing.Size(132, 20);
            this.textBoxdelPrecioADMIN.TabIndex = 11;
            // 
            // AGREGAR
            // 
            this.AGREGAR.BackColor = System.Drawing.Color.LightSkyBlue;
            this.AGREGAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AGREGAR.ForeColor = System.Drawing.Color.Red;
            this.AGREGAR.Location = new System.Drawing.Point(3, 296);
            this.AGREGAR.Name = "AGREGAR";
            this.AGREGAR.Size = new System.Drawing.Size(359, 141);
            this.AGREGAR.TabIndex = 10;
            this.AGREGAR.Text = "AGREGAR";
            this.AGREGAR.UseVisualStyleBackColor = false;
            this.AGREGAR.Click += new System.EventHandler(this.AGREGAR_Click);
            // 
            // CantidadaggADMIN
            // 
            this.CantidadaggADMIN.Location = new System.Drawing.Point(0, 199);
            this.CantidadaggADMIN.Name = "CantidadaggADMIN";
            this.CantidadaggADMIN.Size = new System.Drawing.Size(132, 20);
            this.CantidadaggADMIN.TabIndex = 9;
            this.CantidadaggADMIN.ValueChanged += new System.EventHandler(this.CantidadaggADMIN_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(0, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = " CANTIDAD  ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(233, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 21);
            this.label4.TabIndex = 7;
            this.label4.Text = " PRECIO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(0, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = " PRODUCTO";
            // 
            // comboBoxnameproductsADMIN
            // 
            this.comboBoxnameproductsADMIN.FormattingEnabled = true;
            this.comboBoxnameproductsADMIN.Location = new System.Drawing.Point(0, 114);
            this.comboBoxnameproductsADMIN.Name = "comboBoxnameproductsADMIN";
            this.comboBoxnameproductsADMIN.Size = new System.Drawing.Size(227, 21);
            this.comboBoxnameproductsADMIN.TabIndex = 3;
            this.comboBoxnameproductsADMIN.SelectedIndexChanged += new System.EventHandler(this.comboBoxnameproductsADMIN_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(28, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(306, 37);
            this.label2.TabIndex = 2;
            this.label2.Text = "Taller JJ Martínez.M";
            // 
            // AdminStok
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "AdminStok";
            this.Text = "AdminStok";
            this.Load += new System.EventHandler(this.AdminStok_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CantidadaggADMIN)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TextBoxIdProductoADMIN;
        private System.Windows.Forms.TextBox textBoxdelPrecioADMIN;
        private System.Windows.Forms.Button AGREGAR;
        private System.Windows.Forms.NumericUpDown CantidadaggADMIN;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxnameproductsADMIN;
        private System.Windows.Forms.Label label2;
    }
}