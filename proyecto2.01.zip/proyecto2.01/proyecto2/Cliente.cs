﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto2
{
    public partial class Cliente : Form
    {
        Back objetConexion;
        public Cliente()
        {
            InitializeComponent();
            objetConexion = new Back();

        }

        private void Cliente_Load(object sender, EventArgs e)
        {
            //objetConexion.GETClientes(dataGridCliente);
        }

        private void BTNaddcliente_Click(object sender, EventArgs e)
        {
            objetConexion.LOADDATAClientes(NombreCliente, DireccionCliente, CorreoCliente, NitCliente);
            //objetConexion.GETClientes(dataGridCliente);
        }
    }
}
