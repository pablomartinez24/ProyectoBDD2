﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace proyecto2
{
    public partial class Form1 : Form
    {

        Back objetConexion;
        public Form1()
        {
            InitializeComponent();

            objetConexion = new Back();

        objetConexion.GETInventario(DATAGRIDiNVENTARY);
            objetConexion.GETProductos(dataGridViewProductos);
            
        }

        public void BTNAGGPRODUCT_Click(object sender, EventArgs e)
        {
            objetConexion.LOADDATAProducts(DESCRIPCIONPRODUCT, IDMARCAPRODUCT, IDCATEGORIAPRODUCT, PRECIO);
            objetConexion.GETInventario(DATAGRIDiNVENTARY);
            objetConexion.GETProductos(dataGridViewProductos);


        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void STOCK_Click(object sender, EventArgs e)
        {
            AdminStok admin = new AdminStok();
            admin.Show();
            this.Close();
        }
    }
}
